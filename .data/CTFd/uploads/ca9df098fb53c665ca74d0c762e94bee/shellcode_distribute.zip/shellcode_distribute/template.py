#!/usr/bin/python3

from pwn import *

# This encodes a relative jump some bytes ahead
input1 = b'\xAA' # REPLACE ME 
# This is where the jump takes you. Maybe think of doing:
# - massive nop sled
# - shellcode
input2 = b'\xBB' # REPLACE ME 

# If you got the inputs right, the rest of this script should work fine!

# REMOTE PARAMS
do_remote = 1
remote_ip = "shellcoding.nu-capture-the-flag-codelab.kctf.cloud"
remote_port = 1337

if do_remote:
    p = remote(remote_ip, remote_port)
else:
    p = process("./shellcoding")

p.recvuntil(b'Give me your input:\n')
p.sendline(input1)

p.recvuntil(b'Okay add some shellcode to finish off the program!\n')
p.sendline(input2)

p.interactive()
