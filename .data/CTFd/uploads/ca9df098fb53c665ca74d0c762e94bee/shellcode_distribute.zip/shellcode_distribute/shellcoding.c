#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

char * msg = "----Welcome to the shellcoding challenge!----\n"
	"Today, we'll be doing something very similar to what you did in the lab.... but with a slight twist.\n"
	"Since we're friends, let's work together to make a fun program!!\n"
	"Here's how our game will work:\n"
	"  1. I'll allocate a buffer\n"
	"  2. You'll add some shellcode\n"
	"  3. I'll add some shellcode\n"
	"  4. You'll add some shellcode\n"
	"  5. Finally, I'll run our co-created program!\n";

char * jump_hint = "HINT 1: Checkout x64's relative jmp :)\n";

char * buf_map_hint = "HINT 2: This is what the buffer looks like:\n"
	"16 bytes: Your first input\n"
	"46 bytes: my stuff >:)\n"
	"256 bytes: Your second input\n";

// Oopsie
char * my_shellcode = "\x48\xbf\x4c\x4f\x4c\x20\x52\x49\x50\x0a\x57\x48\xc7\xc7\x01\x00\x00\x00\x48\x89\xe6\x48\xc7\xc2\x08\x00\x00\x00\x48\xc7\xc0\x01\x00\x00\x00\x0f\x05\x48\xc7\xc0\x3c\x00\x00\x00\x0f\x05"; 

int main() {
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	void * buf = malloc(0x1000);
	// Stay in school kids >.<
	mprotect((void*)((unsigned long)buf & ~(0xFFFUL)),0x1000, PROT_EXEC | PROT_READ | PROT_WRITE); 
	puts(msg);
	puts(jump_hint);
	puts(buf_map_hint);

	// Let me set it to NOPs so we don't die instantly :)
	memset(buf, 0x90, 0x1000);

	puts("Okay, I've allocated buffer");
	puts("Give me your input:");
	fgets(buf, 0x10, stdin);

	puts("Awesome, now let me add my input...");
	memcpy(buf + 16, my_shellcode, 46);

	puts("Okay add some shellcode to finish off the program!");
	fgets(buf + 16 + 46, 0x100, stdin);	

	((void(*)(void))(buf))();

	return 0;
}
