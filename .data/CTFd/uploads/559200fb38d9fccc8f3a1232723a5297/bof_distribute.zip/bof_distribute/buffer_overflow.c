#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

void win_func(void) {
	execve("/bin/bash", NULL, NULL);
	exit(0);
}

struct note {
	char * buf;
	uint64_t size;
};

void vulnerable_func(void) {
	struct note n1;
	char local_buf1[48];

	n1.buf = malloc(20);
	n1.size = 20;

	puts("\nRunning Vulnerable Func");
	puts("Printing this couldn't hurt right...");
	printf("local_buf1 addr: %p\n", &local_buf1);
	puts("Write stuff into local_buf1:");

	fgets(local_buf1, 64, stdin);

	puts("Write stuff into n1's buffer... which... is definitely on heap... right...?");

	fgets(n1.buf, n1.size, stdin);

	puts("Local buf contents:");
	puts(local_buf1);
	// I'm taking this out because I don't want to be mean.
	// Trust me this makes your life nice and happy
	/*
	puts("Note buf contents:");
	puts(n1.buf);
	*/
}

int main(void) {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	puts("A simple buffer-overflow challenge w/ a win function :P");
	vulnerable_func();
	puts("Oopsies. Try again?");
	return 0;
}
